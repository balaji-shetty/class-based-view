# This file defines what an "Article" looks like
from django.db import models
from django.urls import reverse

# Article = one blog post
class Article(models.Model):
    # Title of the blog (max 200 letters)
    title = models.CharField(max_length=200)
    
    # Full content (long text)
    content = models.TextField()
    
    # Date when created (auto)
    created = models.DateTimeField(auto_now_add=True)
    
    # Date when updated (auto)
    updated = models.DateTimeField(auto_now=True)

    class Meta:
        # Show newest first
        ordering = ['-created']

    # Show title in admin
    def __str__(self):
        return self.title

    # After save, go to this URL
    def get_absolute_url(self):
        # reverse = find URL by name
        # 'article_detail' = name of detail page
        # pk = ID of this article (1, 2, 3...)
        return reverse('article_detail', kwargs={'pk': self.pk})