# This lets you add articles from /admin
from django.contrib import admin
from .models import Article

# Show these columns in admin list
@admin.register(Article)
class ArticleAdmin(admin.ModelAdmin):
    list_display = ('title', 'created')   # Title + date
    search_fields = ('title',)           # Search by title