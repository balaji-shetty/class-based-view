# blog/views.py

from django.shortcuts import render, get_object_or_404, redirect
from .models import Article

def dashboard(request):
    articles = Article.objects.all().order_by('-created')
    if request.method == 'POST':
        Article.objects.create(
            title=request.POST['title'],
            content=request.POST['content']
        )
        return redirect('dashboard')
    return render(request, 'dashboard.html', {'articles': articles})

def article_detail(request, pk):
    article = get_object_or_404(Article, pk=pk)
    return render(request, 'article_detail.html', {'article': article})

def article_edit(request, pk):
    article = get_object_or_404(Article, pk=pk)
    if request.method == 'POST':
        article.title = request.POST['title']
        article.content = request.POST['content']
        article.save()
        return redirect('dashboard')
    return render(request, 'article_form.html', {'article': article})

def article_delete(request, pk):
    article = get_object_or_404(Article, pk=pk)
    if request.method == 'POST':
        article.delete()
        return redirect('dashboard')
    return render(request, 'article_confirm_delete.html', {'article': article})