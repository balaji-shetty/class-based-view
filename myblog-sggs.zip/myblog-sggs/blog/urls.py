# blog/urls.py

from django.urls import path
from . import views

urlpatterns = [
    path('', views.dashboard, name='dashboard'),
    path('article/<int:pk>/', views.article_detail, name='article_detail'),        # function
    path('article/<int:pk>/edit/', views.article_edit, name='article_edit'),      # function
    path('article/<int:pk>/delete/', views.article_delete, name='article_delete'),# function
]